import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  Construction, 
  Ruler, 
  Layout, 
  PlusCircle,
  Trash2,
  Table as TableIcon,
  RotateCcw,
  CheckCircle2,
  Box
} from 'lucide-react';
import { AppTab, ExcavationMode, CalculationInputs, FoundationInputs, FoundationResult, SavedCalculation } from './types';

interface SteelData {
  weight: number;
  allowance: number;
}

const STEEL_CONFIG: Record<string, SteelData> = {
  'RB6': { weight: 0.222, allowance: 0.05 },
  'RB9': { weight: 0.499, allowance: 0.07 },
  'RB12': { weight: 0.888, allowance: 0.09 },
  'RB15': { weight: 1.390, allowance: 0.11 },
  'RB19': { weight: 2.230, allowance: 0.13 },
  'RB25': { weight: 3.850, allowance: 0.15 },
  'DB10': { weight: 0.616, allowance: 0.07 },
  'DB12': { weight: 0.888, allowance: 0.09 },
  'DB16': { weight: 1.580, allowance: 0.11 },
  'DB20': { weight: 2.470, allowance: 0.13 },
  'DB25': { weight: 3.823, allowance: 0.15 },
};

const ExcavationDiagram: React.FC<{ mode: ExcavationMode; inputs: CalculationInputs }> = ({ mode, inputs }) => {
  const { width, length, depth, offset, radius } = inputs;
  const isAllowance = mode === ExcavationMode.WITH_ALLOWANCE;
  const isSeptic = mode === ExcavationMode.SEPTIC_TANK;

  if (!isSeptic) {
    const drawWidth = isAllowance ? width + offset : width;
    const drawLength = isAllowance ? length + offset : length;

    return (
      <div className="w-full bg-white border border-emerald-100 rounded-2xl p-4 overflow-x-auto text-center">
        <svg viewBox="0 0 400 480" className="w-full min-w-[320px] h-auto font-sans mx-auto">
          <g transform="translate(100, 30)">
            <text x="100" y="-15" textAnchor="middle" className="text-[14px] font-bold fill-emerald-900">รูปแปลน (Top View)</text>
            <line x1="0" y1="10" x2="200" y2="10" stroke="#059669" strokeWidth="1.5" />
            <line x1="0" y1="5" x2="0" y2="15" stroke="#059669" strokeWidth="1.5" />
            <line x1="200" y1="5" x2="200" y2="15" stroke="#059669" strokeWidth="1.5" />
            <rect x="65" y="-10" width="70" height="26" fill="white" fillOpacity="0.95" rx="4" />
            <text x="100" y="2" textAnchor="middle" dominantBaseline="middle" className="text-[18px] fill-emerald-700 font-black">{drawWidth.toFixed(2)} ม.</text>
            <rect x="0" y="30" width="200" height="150" fill="none" stroke="#334155" strokeWidth="2" />
            {isAllowance && <rect x="25" y="55" width="150" height="100" fill="none" stroke="#94a3b8" strokeWidth="1" strokeDasharray="4" />}
            <rect x="90" y="95" width="20" height="20" fill="#cbd5e1" stroke="#334155" strokeWidth="1.5" />
            <line x1="225" y1="30" x2="225" y2="180" stroke="#059669" strokeWidth="1.5" />
            <g transform="rotate(90, 245, 105)">
              <rect x="210" y="95" width="70" height="26" fill="white" fillOpacity="0.95" rx="4" />
              <text x="245" y="108" textAnchor="middle" dominantBaseline="middle" className="text-[18px] fill-emerald-700 font-black">{drawLength.toFixed(2)} ม.</text>
            </g>
          </g>
          <g transform="translate(100, 260)">
            <text x="100" y="-15" textAnchor="middle" className="text-[14px] font-bold fill-emerald-900">รูปตัด (Section View)</text>
            <line x1="-50" y1="30" x2="250" y2="30" stroke="#94a3b8" strokeWidth="1.5" />
            <path d="M20,30 L20,180 L180,180 L180,30" fill="none" stroke="#334155" strokeWidth="2" />
            <rect x="20" y="140" width="160" height="20" fill="#e2e8f0" stroke="#334155" strokeWidth="1.5" />
            <line x1="215" y1="30" x2="215" y2="180" stroke="#059669" strokeWidth="1.5" />
            <g transform="rotate(90, 240, 105)">
              <rect x="205" y="95" width="80" height="26" fill="white" fillOpacity="0.95" rx="4" />
              <text x="245" y="108" textAnchor="middle" dominantBaseline="middle" className="text-[18px] fill-emerald-700 font-black">ลึก {depth.toFixed(2)} ม.</text>
            </g>
          </g>
        </svg>
      </div>
    );
  }

  return (
    <div className="w-full bg-white border border-emerald-100 rounded-2xl p-4 text-center">
      <svg viewBox="0 0 400 300" className="w-full h-auto font-sans mx-auto">
        <g transform="translate(200, 150)">
          <circle cx="0" cy="0" r="80" fill="none" stroke="#334155" strokeWidth="2" />
          <line x1="0" y1="0" x2="80" y2="0" stroke="#059669" strokeWidth="2" />
          <text x="50" y="-10" textAnchor="middle" className="text-[18px] fill-emerald-700 font-black">R {radius.toFixed(2)}</text>
        </g>
      </svg>
    </div>
  );
};

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.EXCAVATION);
  const [pitName, setPitName] = useState<string>('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [savedCalculations, setSavedCalculations] = useState<SavedCalculation[]>([]);

  // Excavation States
  const [excavationMode, setExcavationMode] = useState<ExcavationMode>(ExcavationMode.NO_ALLOWANCE);
  const [excavationInputs, setExcavationInputs] = useState<CalculationInputs>({
    width: 1.0, length: 1.0, depth: 1.5, quantity: 1, offset: 0.3, radius: 0.6
  });

  // Foundation States
  const [foundationInputs, setFoundationInputs] = useState<FoundationInputs>({
    name: '', width: 1.0, length: 1.0, quantity: 1,
    sandThickness: 0.05, sandFactor: 1.25,
    leanThickness: 0.05, rcThickness: 0.25,
    formworkFactor: 0.8, steelType: 'DB', steelSize: 12,
    steelLengthPerBar: 1.5, steelBarsPerFoundation: 10
  });

  // Split saved calculations for separate tables
  const excavationItems = useMemo(() => savedCalculations.filter(c => c.type === AppTab.EXCAVATION), [savedCalculations]);
  const foundationItems = useMemo(() => savedCalculations.filter(c => c.type === AppTab.FOUNDATION), [savedCalculations]);

  // Calculations
  const excavationVolume = useMemo(() => {
    let volume = 0;
    if (excavationMode === ExcavationMode.SEPTIC_TANK) {
      volume = Math.PI * Math.pow(excavationInputs.radius, 2) * excavationInputs.depth * excavationInputs.quantity;
    } else if (excavationMode === ExcavationMode.WITH_ALLOWANCE) {
      const w = excavationInputs.width + excavationInputs.offset;
      const l = excavationInputs.length + excavationInputs.offset;
      volume = w * l * excavationInputs.depth * excavationInputs.quantity;
    } else {
      volume = excavationInputs.width * excavationInputs.length * excavationInputs.depth * excavationInputs.quantity;
    }
    return volume;
  }, [excavationMode, excavationInputs]);

  const fResults = useMemo<FoundationResult>(() => {
    const area = foundationInputs.width * foundationInputs.length;
    const perimeter = 2 * (foundationInputs.width + foundationInputs.length);
    const q = foundationInputs.quantity;

    const sandVolume = area * foundationInputs.sandThickness * q * foundationInputs.sandFactor;
    const leanVolume = area * foundationInputs.leanThickness * q;
    const rcVolume = area * foundationInputs.rcThickness * q;
    const formworkArea = perimeter * foundationInputs.rcThickness * q;
    const formworkMaterial = formworkArea * foundationInputs.formworkFactor;
    const timberBracing = formworkMaterial * 0.3;
    const nails = formworkArea * 0.25;
    
    const steelLabel = `${foundationInputs.steelType}${foundationInputs.steelSize}`;
    const steelConfig = STEEL_CONFIG[steelLabel] || { weight: 0, allowance: 0 };
    
    const totalSteelLength = foundationInputs.steelLengthPerBar * foundationInputs.steelBarsPerFoundation * q;
    const allowanceRate = steelConfig.allowance;
    const steelLengthWithAllowance = totalSteelLength * (1 + allowanceRate);
    const tieWireWeight = steelLengthWithAllowance * steelConfig.weight * 0.03;

    return { 
      area, perimeter, sandVolume, leanVolume, rcVolume, formworkArea, 
      formworkMaterial, timberBracing, nails, steelLabel, totalSteelLength, 
      steelLengthWithAllowance, allowanceRate, tieWireWeight 
    };
  }, [foundationInputs]);

  const handleSave = () => {
    let newSave: SavedCalculation;
    if (activeTab === AppTab.EXCAVATION) {
      newSave = {
        id: crypto.randomUUID(),
        type: AppTab.EXCAVATION,
        name: pitName || (excavationMode === ExcavationMode.SEPTIC_TANK ? 'บ่อเกรอะ' : `หลุมขุด #${excavationItems.length + 1}`),
        mode: excavationMode,
        inputs: { ...excavationInputs },
        volume: excavationVolume
      };
    } else {
      newSave = {
        id: crypto.randomUUID(),
        type: AppTab.FOUNDATION,
        name: foundationInputs.name || `ฐานราก #${foundationItems.length + 1}`,
        inputs: { ...foundationInputs },
        foundationResult: { ...fResults }
      };
    }
    setSavedCalculations([...savedCalculations, newSave]);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
  };

  const removeSaved = (id: string) => setSavedCalculations(savedCalculations.filter(c => c.id !== id));
  const clearAll = () => window.confirm('ลบรายการทั้งหมด?') && setSavedCalculations([]);

  const totalExcavation = useMemo(() => excavationItems.reduce((sum, c) => sum + (c.volume || 0), 0), [excavationItems]);
  const totalRC = useMemo(() => foundationItems.reduce((sum, c) => sum + (c.foundationResult?.rcVolume || 0), 0), [foundationItems]);
  const totalSteelLength = useMemo(() => foundationItems.reduce((sum, c) => sum + (c.foundationResult?.steelLengthWithAllowance || 0), 0), [foundationItems]);
  const totalTieWireWeight = useMemo(() => foundationItems.reduce((sum, c) => sum + (c.foundationResult?.tieWireWeight || 0), 0), [foundationItems]);
  
  // New totals for detailed foundation summary
  const totalSand = useMemo(() => foundationItems.reduce((sum, c) => sum + (c.foundationResult?.sandVolume || 0), 0), [foundationItems]);
  const totalLean = useMemo(() => foundationItems.reduce((sum, c) => sum + (c.foundationResult?.leanVolume || 0), 0), [foundationItems]);
  const totalFormwork = useMemo(() => foundationItems.reduce((sum, c) => sum + (c.foundationResult?.formworkMaterial || 0), 0), [foundationItems]);
  const totalBracing = useMemo(() => foundationItems.reduce((sum, c) => sum + (c.foundationResult?.timberBracing || 0), 0), [foundationItems]);
  const totalNails = useMemo(() => foundationItems.reduce((sum, c) => sum + (c.foundationResult?.nails || 0), 0), [foundationItems]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-emerald-600 rounded-2xl shadow-lg">
              <Calculator className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-slate-800 tracking-tight">Easy BOQ App</h1>
              <p className="text-slate-500 font-medium font-sans">ระบบคำนวณงานดินและงานฐานรากแบบมืออาชีพ</p>
            </div>
          </div>
          
          <div className="flex bg-white p-1 rounded-2xl shadow-sm border border-slate-200">
            <button 
              onClick={() => setActiveTab(AppTab.EXCAVATION)}
              className={`px-6 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === AppTab.EXCAVATION ? 'bg-emerald-600 text-white shadow-md shadow-emerald-200' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              <Layout className="w-4 h-4" /> งานดินขุด
            </button>
            <button 
              onClick={() => setActiveTab(AppTab.FOUNDATION)}
              className={`px-6 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${activeTab === AppTab.FOUNDATION ? 'bg-emerald-600 text-white shadow-md shadow-emerald-200' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              <Box className="w-4 h-4" /> งานฐานราก
            </button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Inputs Section */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white rounded-[2rem] p-6 shadow-sm border border-slate-100 space-y-6">
              <h2 className="text-lg font-bold flex items-center gap-2">
                <Ruler className="w-5 h-5 text-emerald-600" /> ข้อมูลตั้งค่า
              </h2>

              {activeTab === AppTab.EXCAVATION ? (
                <div className="space-y-4">
                  <input 
                    type="text" placeholder="ชื่อรายการ..." value={pitName} onChange={(e) => setPitName(e.target.value)}
                    className="w-full bg-slate-50 border-none rounded-xl p-4 font-bold"
                  />
                  <div className="grid grid-cols-1 gap-2">
                    <button onClick={() => setExcavationMode(ExcavationMode.NO_ALLOWANCE)} className={`p-3 rounded-xl text-left border transition-all ${excavationMode === ExcavationMode.NO_ALLOWANCE ? 'bg-emerald-50 border-emerald-500 font-bold text-emerald-700' : 'border-slate-100 text-slate-500 hover:border-emerald-200'}`}>
                      ขุดไม่เผื่อ
                    </button>
                    <button onClick={() => setExcavationMode(ExcavationMode.WITH_ALLOWANCE)} className={`p-3 rounded-xl text-left border transition-all ${excavationMode === ExcavationMode.WITH_ALLOWANCE ? 'bg-emerald-50 border-emerald-500 font-bold text-emerald-700' : 'border-slate-100 text-slate-500 hover:border-emerald-200'}`}>
                      ขุดแบบเผื่อ
                    </button>
                    <button onClick={() => setExcavationMode(ExcavationMode.SEPTIC_TANK)} className={`p-3 rounded-xl text-left border transition-all ${excavationMode === ExcavationMode.SEPTIC_TANK ? 'bg-emerald-50 border-emerald-500 font-bold text-emerald-700' : 'border-slate-100 text-slate-500 hover:border-emerald-200'}`}>
                      บ่อเกรอะ
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    {excavationMode !== ExcavationMode.SEPTIC_TANK ? (
                      <>
                        <div className="space-y-1">
                          <label className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">กว้าง (ม.)</label>
                          <input type="number" step="0.1" value={excavationInputs.width} onChange={e => setExcavationInputs({...excavationInputs, width: +e.target.value})} className="w-full bg-slate-50 rounded-xl p-3 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">ยาว (ม.)</label>
                          <input type="number" step="0.1" value={excavationInputs.length} onChange={e => setExcavationInputs({...excavationInputs, length: +e.target.value})} className="w-full bg-slate-50 rounded-xl p-3 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                        </div>
                        {excavationMode === ExcavationMode.WITH_ALLOWANCE && (
                          <div className="col-span-2 space-y-1">
                            <label className="text-[10px] text-emerald-600 font-bold uppercase tracking-tight">ระยะเผื่อ (ม.)</label>
                            <input type="number" step="0.1" value={excavationInputs.offset} onChange={e => setExcavationInputs({...excavationInputs, offset: +e.target.value})} className="w-full bg-emerald-50 border border-emerald-100 rounded-xl p-3 font-bold text-emerald-700 focus:ring-2 focus:ring-emerald-500 outline-none" />
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="col-span-2 space-y-1">
                        <label className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">รัศมี (ม.)</label>
                        <input type="number" step="0.1" value={excavationInputs.radius} onChange={e => setExcavationInputs({...excavationInputs, radius: +e.target.value})} className="w-full bg-slate-50 rounded-xl p-3 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                      </div>
                    )}
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">ลึก (ม.)</label>
                      <input type="number" step="0.1" value={excavationInputs.depth} onChange={e => setExcavationInputs({...excavationInputs, depth: +e.target.value})} className="w-full bg-slate-50 rounded-xl p-3 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">จำนวน (หลุม)</label>
                      <input type="number" value={excavationInputs.quantity} onChange={e => setExcavationInputs({...excavationInputs, quantity: +e.target.value})} className="w-full bg-slate-50 rounded-xl p-3 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4 text-sm font-medium">
                  <input 
                    type="text" placeholder="ชื่อฐานราก (เช่น F1)..." value={foundationInputs.name} onChange={(e) => setFoundationInputs({...foundationInputs, name: e.target.value})}
                    className="w-full bg-slate-50 border-none rounded-xl p-4 font-bold text-base outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                  <div className="grid grid-cols-3 gap-2">
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400">กว้าง (ม.)</label>
                      <input type="number" step="0.1" value={foundationInputs.width} onChange={e => setFoundationInputs({...foundationInputs, width: +e.target.value})} className="w-full bg-slate-50 rounded-lg p-2 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400">ยาว (ม.)</label>
                      <input type="number" step="0.1" value={foundationInputs.length} onChange={e => setFoundationInputs({...foundationInputs, length: +e.target.value})} className="w-full bg-slate-50 rounded-lg p-2 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] text-slate-400">จำนวน</label>
                      <input type="number" value={foundationInputs.quantity} onChange={e => setFoundationInputs({...foundationInputs, quantity: +e.target.value})} className="w-full bg-slate-50 rounded-lg p-2 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                    </div>
                  </div>
                  
                  <div className="space-y-3 pt-2">
                    <div className="flex items-center justify-between">
                      <label className="text-xs">ทรายหยาบ (หนา/เผื่อ)</label>
                      <div className="flex gap-2">
                        <input type="number" step="0.01" value={foundationInputs.sandThickness} onChange={e => setFoundationInputs({...foundationInputs, sandThickness: +e.target.value})} className="w-16 bg-slate-50 rounded-lg p-1 font-bold text-center" />
                        <select value={foundationInputs.sandFactor} onChange={e => setFoundationInputs({...foundationInputs, sandFactor: +e.target.value})} className="bg-slate-50 rounded-lg p-1 text-xs font-bold outline-none">
                          <option value={1.25}>1.25</option><option value={1.30}>1.30</option><option value={1.35}>1.35</option>
                        </select>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="text-xs">คอนกรีตหยาบ (หนา)</label>
                      <input type="number" step="0.01" value={foundationInputs.leanThickness} onChange={e => setFoundationInputs({...foundationInputs, leanThickness: +e.target.value})} className="w-20 bg-slate-50 rounded-lg p-1 font-bold text-center" />
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="text-xs">ค.ส.ล. (หนา)</label>
                      <input type="number" step="0.01" value={foundationInputs.rcThickness} onChange={e => setFoundationInputs({...foundationInputs, rcThickness: +e.target.value})} className="w-20 bg-slate-50 rounded-lg p-1 font-bold text-center" />
                    </div>
                  </div>

                  <div className="space-y-3 border-t pt-4">
                    <label className="text-xs font-bold text-emerald-600 uppercase tracking-widest">เหล็กเสริมและไม้แบบ</label>
                    <div className="grid grid-cols-2 gap-2">
                      <select value={foundationInputs.steelType} onChange={e => setFoundationInputs({...foundationInputs, steelType: e.target.value as any})} className="bg-slate-50 rounded-lg p-2 font-bold outline-none">
                        <option value="RB">RB</option><option value="DB">DB</option>
                      </select>
                      <select value={foundationInputs.steelSize} onChange={e => setFoundationInputs({...foundationInputs, steelSize: +e.target.value})} className="bg-slate-50 rounded-lg p-2 font-bold outline-none">
                        {foundationInputs.steelType === 'RB' ? [6,9,12,15,19,25].map(s => <option key={s} value={s}>{s}</option>) : [10,12,16,20,25].map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[10px]">ยาว/เส้น (ม.)</label>
                        <input type="number" step="0.1" value={foundationInputs.steelLengthPerBar} onChange={e => setFoundationInputs({...foundationInputs, steelLengthPerBar: +e.target.value})} className="w-full bg-slate-50 rounded-lg p-2 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px]">เส้น/ฐาน</label>
                        <input type="number" value={foundationInputs.steelBarsPerFoundation} onChange={e => setFoundationInputs({...foundationInputs, steelBarsPerFoundation: +e.target.value})} className="w-full bg-slate-50 rounded-lg p-2 font-bold focus:ring-2 focus:ring-emerald-500 outline-none" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2">
                      <label className="text-xs">สัมประสิทธิ์ไม้แบบ</label>
                      <select value={foundationInputs.formworkFactor} onChange={e => setFoundationInputs({...foundationInputs, formworkFactor: +e.target.value})} className="bg-slate-50 rounded-lg p-1 text-xs font-bold outline-none">
                        <option value={0.8}>0.8</option><option value={0.7}>0.7</option><option value={0.6}>0.6</option><option value={0.5}>0.5</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              <button 
                onClick={handleSave}
                className={`w-full py-4 rounded-2xl font-black text-xl shadow-xl transition-all flex items-center justify-center gap-2 ${showSuccess ? 'bg-emerald-500 text-white' : 'bg-emerald-600 hover:bg-emerald-700 text-white'}`}
              >
                {showSuccess ? <CheckCircle2 className="animate-bounce" /> : <PlusCircle />} บันทึกรายการ
              </button>
            </div>
          </div>

          {/* Visualization & Summary Section */}
          <div className="lg:col-span-8 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-[2rem] p-8 shadow-sm border border-slate-100 flex flex-col items-center justify-center">
                <h3 className="text-xl font-bold mb-6 text-slate-800">แสดงผลคำนวณ</h3>
                {activeTab === AppTab.EXCAVATION ? (
                  <div className="text-center space-y-4">
                    <ExcavationDiagram mode={excavationMode} inputs={excavationInputs} />
                    <div className="pt-4">
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">
                        {excavationMode === ExcavationMode.WITH_ALLOWANCE ? 'ปริมาตรดินขุด (แบบเผื่อ)' : 'ปริมาตรดินขุด (ไม่เผื่อ)'}
                      </div>
                      <div className="text-5xl font-black text-emerald-600 tracking-tight">{excavationVolume.toFixed(3)}</div>
                      <div className="text-sm font-bold text-slate-400">ลบ.ม.</div>
                      
                      {excavationMode === ExcavationMode.WITH_ALLOWANCE && (
                        <div className="mt-4 p-3 bg-emerald-50 rounded-xl text-[10px] font-bold text-emerald-700">
                          สูตร: ({excavationInputs.width} + {excavationInputs.offset}) × ({excavationInputs.length} + {excavationInputs.offset}) × {excavationInputs.depth} × {excavationInputs.quantity}
                        </div>
                      )}
                    </div>
                  </div>
                ) : (
                  <div className="w-full space-y-2 text-sm font-sans">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-emerald-50 rounded-xl">
                        <span className="block text-[10px] font-bold text-emerald-600 uppercase tracking-tight">คอนกรีต RC</span>
                        <span className="text-xl font-black">{fResults.rcVolume.toFixed(3)} ลบ.ม.</span>
                      </div>
                      <div className="p-3 bg-blue-50 rounded-xl">
                        <span className="block text-[10px] font-bold text-blue-600 uppercase tracking-tight">เหล็ก {fResults.steelLabel} (รวมเผื่อ)</span>
                        <span className="text-xl font-black">{fResults.steelLengthWithAllowance.toFixed(2)} ม.</span>
                      </div>
                    </div>
                    <div className="p-4 bg-slate-50 rounded-2xl space-y-2 font-medium text-slate-700">
                      <div className="flex justify-between border-b pb-1"><span>ทรายหยาบ</span><span className="font-bold text-slate-900">{fResults.sandVolume.toFixed(3)} ลบ.ม.</span></div>
                      <div className="flex justify-between border-b pb-1"><span>คอนกรีตหยาบ</span><span className="font-bold text-slate-900">{fResults.leanVolume.toFixed(3)} ลบ.ม.</span></div>
                      <div className="flex justify-between border-b pb-1"><span>เนื้อที่ไม้แบบ</span><span className="font-bold text-slate-900">{fResults.formworkArea.toFixed(2)} ตร.ม.</span></div>
                      <div className="flex justify-between border-b pb-1"><span>วัสดุไม้แบบ</span><span className="font-bold text-slate-900">{fResults.formworkMaterial.toFixed(2)} ตร.ม.</span></div>
                      <div className="flex justify-between border-b pb-1"><span>ไม้คร่าว</span><span className="font-bold text-slate-900">{fResults.timberBracing.toFixed(2)} ตร.ม.</span></div>
                      <div className="flex justify-between border-b pb-1"><span>ตะปู</span><span className="font-bold text-slate-900">{fResults.nails.toFixed(2)} กก.</span></div>
                      
                      <div className="flex flex-col border-b pb-2 pt-1 text-blue-700">
                        <div className="flex justify-between font-black text-sm">
                          <span>ความยาวเหล็กเผื่อ {(fResults.allowanceRate * 100).toFixed(0)}%</span>
                          <span>
                            {fResults.totalSteelLength.toFixed(2)} + {(fResults.allowanceRate * 100).toFixed(0)}% = {fResults.steelLengthWithAllowance.toFixed(2)} ม.
                          </span>
                        </div>
                      </div>

                      <div className="flex justify-between pt-1 text-orange-600 font-black text-base">
                        <span>ลวดผูกเหล็ก</span>
                        <span>{fResults.tieWireWeight.toFixed(3)} กก.</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Total Summary Card */}
              <div className="space-y-6">
                <div className="bg-emerald-600 rounded-[2rem] p-8 text-white shadow-xl shadow-emerald-100 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-8 opacity-10">
                    <Calculator className="w-32 h-32" />
                  </div>
                  <div className="flex items-center gap-2 mb-6 opacity-80">
                    <Construction className="w-5 h-5" />
                    <span className="text-xs font-bold uppercase tracking-widest">ภาพรวมโครงการทั้งหมด</span>
                  </div>
                  <div className="space-y-6">
                    <div>
                      <span className="text-xs font-bold opacity-70 block uppercase tracking-wide">ดินขุดสะสม</span>
                      <span className="text-4xl font-black">{totalExcavation.toFixed(3)} <small className="text-sm font-medium">ลบ.ม.</small></span>
                    </div>
                    <div>
                      <span className="text-xs font-bold opacity-70 block uppercase tracking-wide">คอนกรีต RC สะสม</span>
                      <span className="text-4xl font-black">{totalRC.toFixed(3)} <small className="text-sm font-medium">ลบ.ม.</small></span>
                    </div>
                    <div>
                      <span className="text-xs font-bold opacity-70 block uppercase tracking-wide">ความยาวเหล็กสะสม (รวมเผื่อ)</span>
                      <span className="text-4xl font-black">{totalSteelLength.toFixed(2)} <small className="text-sm font-medium">ม.</small></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Separated Tables Section */}
            <div className="space-y-12 pb-12">
              
              {/* Excavation Summary Table */}
              {excavationItems.length > 0 && (
                <section className="bg-white rounded-[2rem] p-8 shadow-sm border border-slate-100 overflow-hidden font-sans">
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="text-xl font-black flex items-center gap-2 text-slate-800">
                        <Layout className="text-emerald-600 w-6 h-6" /> สรุปรายการงานดินขุด
                      </h3>
                      <p className="text-slate-400 text-xs font-medium mt-1 tracking-tight">รายการขุดดินทั้งหมดที่บันทึกไว้</p>
                    </div>
                    {savedCalculations.length > 0 && (
                      <button onClick={clearAll} className="text-[10px] font-black text-slate-300 hover:text-red-500 transition-colors flex items-center gap-1 uppercase tracking-widest">
                        <RotateCcw className="w-3 h-3"/> ล้างทั้งหมด
                      </button>
                    )}
                  </div>
                  <div className="overflow-x-auto -mx-2">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="border-b text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          <th className="px-4 pb-4">ชื่อรายการ</th>
                          <th className="px-4 pb-4">ประเภทการขุด</th>
                          <th className="px-4 pb-4 text-right">ปริมาตร (ลบ.ม.)</th>
                          <th className="px-4 pb-4 text-center">จัดการ</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y text-sm font-medium">
                        {excavationItems.map(c => {
                          return (
                            <tr key={c.id} className="group hover:bg-slate-50 transition-colors">
                              <td className="px-4 py-4 font-bold text-slate-800">{c.name}</td>
                              <td className="px-4 py-4">
                                <span className={`text-[10px] px-2 py-1 rounded-full font-black uppercase tracking-tight ${c.mode === ExcavationMode.SEPTIC_TANK ? 'bg-purple-100 text-purple-600' : 'bg-orange-100 text-orange-600'}`}>
                                  {c.mode === ExcavationMode.NO_ALLOWANCE ? 'ไม่เผื่อ' : c.mode === ExcavationMode.WITH_ALLOWANCE ? 'แบบเผื่อ' : 'บ่อเกรอะ'}
                                </span>
                              </td>
                              <td className="px-4 py-4 text-right font-black text-emerald-600 text-base">{c.volume?.toFixed(3)}</td>
                              <td className="px-4 py-4 text-center">
                                <button onClick={() => removeSaved(c.id)} className="text-slate-200 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4"/></button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                      <tfoot>
                        <tr className="bg-emerald-50/50">
                          <td colSpan={2} className="px-4 py-4 font-black text-emerald-800 uppercase tracking-wider">งานดินขุดรวมปริมาตรทั้งหมด</td>
                          <td className="px-4 py-4 text-right font-black text-emerald-600 text-xl border-t-2 border-emerald-200">
                            {totalExcavation.toFixed(3)}
                          </td>
                          <td></td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </section>
              )}

              {/* Foundation Summary Table */}
              {foundationItems.length > 0 && (
                <section className="bg-white rounded-[2rem] p-8 shadow-sm border border-slate-100 overflow-hidden font-sans">
                  <div className="flex items-center justify-between mb-8">
                    <div>
                      <h3 className="text-xl font-black flex items-center gap-2 text-slate-800">
                        <Box className="text-blue-600 w-6 h-6" /> สรุปรายการงานฐานราก
                      </h3>
                      <p className="text-slate-400 text-xs font-medium mt-1 tracking-tight">รายละเอียดวัสดุฐานรากทั้งหมด</p>
                    </div>
                    {savedCalculations.length > 0 && (
                       <button onClick={clearAll} className="text-[10px] font-black text-slate-300 hover:text-red-500 transition-colors flex items-center gap-1 uppercase tracking-widest">
                        <RotateCcw className="w-3 h-3"/> ล้างทั้งหมด
                      </button>
                    )}
                  </div>
                  <div className="overflow-x-auto -mx-2">
                    <table className="w-full text-left whitespace-nowrap">
                      <thead>
                        <tr className="border-b text-[10px] font-black text-slate-400 uppercase tracking-widest">
                          <th className="px-4 pb-4">ฐานราก</th>
                          <th className="px-4 pb-4 text-right">RC (ลบ.ม.)</th>
                          <th className="px-4 pb-4 text-right">ทราย (ลบ.ม.)</th>
                          <th className="px-4 pb-4 text-right">ค.หยาบ (ลบ.ม.)</th>
                          <th className="px-4 pb-4 text-right">ไม้แบบ (ตร.ม.)</th>
                          <th className="px-4 pb-4 text-right">ไม้คร่าว (ตร.ม.)</th>
                          <th className="px-4 pb-4 text-right">ตะปู (กก.)</th>
                          <th className="px-4 pb-4 text-right">เหล็ก (ม.)</th>
                          <th className="px-4 pb-4 text-right">ลวด (กก.)</th>
                          <th className="px-4 pb-4 text-center">จัดการ</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y text-xs font-medium">
                        {foundationItems.map(c => {
                          const res = c.foundationResult!;
                          return (
                            <tr key={c.id} className="group hover:bg-slate-50 transition-colors">
                              <td className="px-4 py-4 font-bold text-slate-800">{c.name}</td>
                              <td className="px-4 py-4 text-right font-black text-blue-600">{res.rcVolume.toFixed(3)}</td>
                              <td className="px-4 py-4 text-right text-slate-600">{res.sandVolume.toFixed(3)}</td>
                              <td className="px-4 py-4 text-right text-slate-600">{res.leanVolume.toFixed(3)}</td>
                              <td className="px-4 py-4 text-right text-slate-600">{res.formworkMaterial.toFixed(2)}</td>
                              <td className="px-4 py-4 text-right text-slate-600">{res.timberBracing.toFixed(2)}</td>
                              <td className="px-4 py-4 text-right text-slate-600">{res.nails.toFixed(2)}</td>
                              <td className="px-4 py-4 text-right font-black text-slate-800">
                                <div className="text-[9px] text-blue-500">{res.steelLabel}</div>
                                {res.steelLengthWithAllowance.toFixed(2)}
                              </td>
                              <td className="px-4 py-4 text-right font-black text-orange-600">{res.tieWireWeight.toFixed(3)}</td>
                              <td className="px-4 py-4 text-center">
                                <button onClick={() => removeSaved(c.id)} className="text-slate-200 hover:text-red-500 transition-colors"><Trash2 className="w-4 h-4"/></button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                      <tfoot>
                        <tr className="bg-slate-50 font-black text-slate-700">
                          <td className="px-4 py-4 uppercase text-[10px]">รวมทั้งหมด</td>
                          <td className="px-4 py-4 text-right text-blue-600 border-t-2 border-blue-100">{totalRC.toFixed(3)}</td>
                          <td className="px-4 py-4 text-right border-t-2 border-slate-200">{totalSand.toFixed(3)}</td>
                          <td className="px-4 py-4 text-right border-t-2 border-slate-200">{totalLean.toFixed(3)}</td>
                          <td className="px-4 py-4 text-right border-t-2 border-slate-200">{totalFormwork.toFixed(2)}</td>
                          <td className="px-4 py-4 text-right border-t-2 border-slate-200">{totalBracing.toFixed(2)}</td>
                          <td className="px-4 py-4 text-right border-t-2 border-slate-200">{totalNails.toFixed(2)}</td>
                          <td className="px-4 py-4 text-right border-t-2 border-slate-200">{totalSteelLength.toFixed(2)}</td>
                          <td className="px-4 py-4 text-right text-orange-600 border-t-2 border-orange-100">{totalTieWireWeight.toFixed(3)}</td>
                          <td></td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </section>
              )}

            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;