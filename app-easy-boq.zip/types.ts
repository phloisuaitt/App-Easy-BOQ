export enum AppTab {
  EXCAVATION = 'EXCAVATION',
  FOUNDATION = 'FOUNDATION'
}

export enum ExcavationMode {
  NO_ALLOWANCE = 'NO_ALLOWANCE',
  WITH_ALLOWANCE = 'WITH_ALLOWANCE',
  SEPTIC_TANK = 'SEPTIC_TANK'
}

export interface CalculationInputs {
  width: number;
  length: number;
  depth: number;
  quantity: number;
  offset: number; 
  radius: number; 
}

export interface FoundationInputs {
  name: string;
  width: number;
  length: number;
  quantity: number;
  sandThickness: number;
  sandFactor: number;
  leanThickness: number;
  rcThickness: number;
  formworkFactor: number;
  steelType: 'RB' | 'DB';
  steelSize: number;
  steelLengthPerBar: number;
  steelBarsPerFoundation: number;
}

export interface FoundationResult {
  area: number;
  perimeter: number;
  sandVolume: number;
  leanVolume: number;
  rcVolume: number;
  formworkArea: number;
  formworkMaterial: number;
  timberBracing: number;
  nails: number;
  steelLabel: string;
  totalSteelLength: number; // Base length
  steelLengthWithAllowance: number; // Length including percentage
  allowanceRate: number;
  tieWireWeight: number; // Formula: LengthWithAllowance * WeightPerMeter * 0.03
}

export interface SavedCalculation {
  id: string;
  type: AppTab;
  name: string;
  mode?: ExcavationMode;
  inputs: CalculationInputs | FoundationInputs;
  volume?: number; // For Excavation
  foundationResult?: FoundationResult; // For Foundation
}