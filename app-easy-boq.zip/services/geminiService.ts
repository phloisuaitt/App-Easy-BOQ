
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSoilAdvice = async (soilType: string, depth: number) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `As a civil engineering expert, provide brief advice (in Thai) for excavating in "${soilType}" at a depth of ${depth} meters. 
      Include safety tips, recommended slope angles, and potential risks like cave-ins. Keep it concise and professional.`,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "ไม่สามารถดึงข้อมูลคำแนะนำจาก AI ได้ในขณะนี้";
  }
};
